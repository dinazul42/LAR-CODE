from enum import Enum, unique, auto
from lorem_text import lorem
from pathlib import Path


@unique
class DummyDataType(Enum):
    Fixed = auto()
    Random = auto()
    Mixed = auto()
    File = auto()


def generate_data(data_length: int, data_type: DummyDataType = DummyDataType.Fixed, **kwargs) -> bytes:
    """This function generates fake data to send to modem for testing. If using file based data, add the filename using
    the "filename" keyword argument.

    :param data_length: length of data in bytes. ignored for file based data
    :param data_type: Should data be fixed, random, mixed, or read from file
    """
    if data_type == DummyDataType.Fixed:
        with open("Lorem_ipsum.txt", "r") as file:
            data = file.read()
        return data.encode("utf-8")[:data_length]
    if data_type == DummyDataType.Random:
        return lorem.words(data_length).encode("utf-8")[:data_length]
    if data_type == DummyDataType.Mixed:
        pass
        # TODO
    if data_type == DummyDataType.File:
        filename = kwargs.get("filename")
        suffix = Path(filename).suffix
        if suffix in (".txt", ".dat", ".log"):
            with open(filename, "r") as file:
                data = file.read()
            return data.encode("utf-8")
        if suffix in (".mavlink", ".bin"):
            with open(filename, "r") as file:
                data = file.read()
            return data.encode("utf-8")


if __name__ == "__main__":
    test = generate_data(1000, DummyDataType.File, filename="Lorem_ipsum.txt")
    pass
