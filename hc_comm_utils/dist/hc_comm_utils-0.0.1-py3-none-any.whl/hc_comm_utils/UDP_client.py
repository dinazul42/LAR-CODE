#from _typeshed import Self
import socket
import concurrent.futures
import logging
import queue
import threading
import copy
from typing import Callable, BinaryIO, Union
import time


format = "%(asctime)s: %(message)s"
logging.basicConfig(format=format, level=logging.INFO,
                    datefmt="%H:%M:%S")

# This object is used to signal a required disconnect
UDP_DISCONNECT_SENTINEL = object()


class UdpClient:
    def __init__(self, hostname: str, port: int, parser_function: Callable, tx_log: str = "",
                 rx_log: str = "", verbosity: int = 1):
        """
        :param hostname: server hostname (IP)
        :param port: server port
        :param parser_function: function to parse incoming bytes. The function must accept a single bytes type argument
        :param tx_log: log filename to write transmitted bytes
        :param rx_log: log filename to write received bytes
        :param int verbosity: how much logging should be printed.
        """
        self.hostname = hostname
        self.port = port
        self.verbosity = verbosity
        self.is_connected: bool = False
        self.thread_manager = None
        self.pipeline = queue.Queue()  # queue used to store messages sent from host to program
        self.termination_event = threading.Event()  # the event can be set to signal threads they should terminate.
        self.parser_function = parser_function
        self.tx_log_filename = tx_log
        self.rx_log_filename = rx_log
        self.tx_log: Union[BinaryIO, None] = None
        self.rx_log: Union[BinaryIO, None] = None

    def _threads_launcher(self):
        """
        Don't call this method. Launches producer and consumer threads upon connection
        """
        self.thread_manager = concurrent.futures.ThreadPoolExecutor(max_workers=2)
        self.thread_manager.submit(self._handler, self.pipeline, self.termination_event, self.parser_function,
                                   self.verbosity)
        self.thread_manager.submit(self._listener, self.pipeline, self.termination_event, self.socket, self.hostname,
                                   self.rx_log, self.verbosity)

    def connect_to_host(self) -> None:
        if self.is_connected:
            self.disconnect_from_host()
        while not self.is_connected:
            try:
                self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                # self.socket.bind((self.hostname, self.port))
                self.is_connected = True
                if self.verbosity > 0:
                    logging.info("Connected to %s:%s", self.hostname, str(self.port))
                if self.tx_log_filename:
                    if self.tx_log:
                        self.tx_log.flush()
                        self.tx_log.close()
                    self.tx_log = open(self.tx_log_filename, 'wb')
                if self.rx_log_filename:
                    if self.rx_log:
                        self.rx_log.flush()
                        self.rx_log.close()
                    self.rx_log = open(self.rx_log_filename, 'wb')
                self.termination_event.clear()
                
                self._threads_launcher()

            except socket.error as e:
                # Something else happened, handle error, exit, etc.
                logging.warning(e)
                time.sleep(2)
            except Exception as e:
                logging.warning(e)
                raise e

    def disconnect_from_host(self):
        self.termination_event.set()
        self.pipeline.put(UDP_DISCONNECT_SENTINEL)

        logging.info('attempting if statement')
        if self.thread_manager is not None:
            logging.info('in if statement')
            self.thread_manager.shutdown(wait=False) # join threads
            logging.info('killed threads')
            self.thread_manager = None
        
        self.socket.close()
        if self.tx_log:
            self.tx_log.flush()
            self.tx_log.close()
            self.tx_log = None
        if self.rx_log:
            self.rx_log.flush()
            self.rx_log.close()
            self.rx_log = None
        self.is_connected = False
        logging.info("is_connected status is %s", self.is_connected)
        if self.verbosity > 0:
            logging.info("Disconnected from %s:%s", self.hostname, str(self.port))

    def write(self, data: bytes) -> Union[int, None]:
        """
        Used to send bytes to host

        :param data: required bytes to be sent
        :return: number of bytes written, None if host isn't connected.
        :rtype: Union[int, None]
        """
        if self.is_connected:
            to_send = len(data)
            sent = 0

            while sent < to_send:
                sent += self.socket.sendto(data[sent:], (self.hostname, self.port))
                if self.verbosity > 1:
                    logging.info('sent %s bytes to %s:%s', sent, self.hostname, self.port)
            if self.tx_log:
                self.tx_log.write(data[:sent])
            return sent

    #@staticmethod
    def _listener(self, pipeline: queue.Queue, termination_event: threading.Event, _socket: socket.socket, hostname: str,
                  rx_log: Union[BinaryIO, None], verbosity: int):
        """
        Don't call this function.
        The listener and handler form a producer consumer relationship using the pipeline.
        The listener feeds data to the pipeline.

        :param pipeline: A queue.Queue object to pass messages to consumer
        :param termination_event: A threading.Event object used to signal required disconnect.
        :param _socket: A socket.socket object to receive data from
        :param hostname: used only for debug messages
        :param rx_log: log filename to write received bytes
        :param int verbosity: how much logging should be printed.
        """
        message = b""
        while not termination_event.is_set():
            try:
                message, addr = self.socket.recvfrom(4096)
            except socket.timeout:
                continue  # read timeout, no action needed
            except socket.error as e:
                # Something else happened, handle error, exit, etc.
                logging.warning(e)
                raise e
            # run if no exception occurred
            else:
                if len(message) == 0:
                    if verbosity > 0:
                        try:
                            logging.info('disconnecting from host')
                            self.disconnect_from_host()
                        except Exception as e:
                            logging.warning(e)
                        finally:
                            pass
                else:
                    if verbosity > 1:
                        if verbosity > 2:
                            logging.info("UDP data received from %s: %s", addr, message)
                        else:
                            logging.info("UDP data received from %s", addr)
                    if rx_log:
                        rx_log.write(message)
                    pipeline.put(message)
        if verbosity > 1:
            logging.info("listener thread exiting")

    @staticmethod
    def _handler(pipeline: queue.Queue, termination_event: threading.Event, parser_function, verbosity: int):
        """
        Don't call this function.
        The listener and handler form a producer consumer relationship using the pipeline.
        The handler consumes messages from the pipeline, and gets them parsed.

        :param pipeline: A queue.Queue object to receive messages from producer
        :param termination_event: A threading.Event object used to signal required disconnect.
        :param parser_function: function to parse incoming bytes. The function must except a single bytes type argument
        :param int verbosity: how much logging should be printed.
        """
        while not termination_event.is_set():
            message = pipeline.get()
            pipeline.task_done()  # indicates to the queue that the processing on the task is complete.
            # allows unblocking of other threads
            if message is not UDP_DISCONNECT_SENTINEL:
                if verbosity > 2:
                    logging.info("Consumer parsing message: %s (size=%d)", message, pipeline.qsize())
                parser_function(copy.deepcopy(message))

        if verbosity > 1:
            logging.info("parser thread exiting")

if __name__ == "__main__":
    import time
    
    def dummy_function(data: bytes):
        print(str(data))
        return str(data)
    client = UdpClient('localhost', 12000, dummy_function, True, verbosity=2)
    client.connect_to_host()
    for i in range(10):
        time.sleep(1)
        client.write_to_host(b"hi there")
    time.sleep(12)
    logging.info("about to disconnect")
    client.disconnect_from_host()

    # # Server instance
    # import random
    # import socket
    # import time
    #
    # server_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # server_socket.bind(('localhost', 12000))
    #
    # while True:
    #     rand = random.randint(0, 10)
    #     message, address = server_socket.recvfrom(1024)
    #     message = message.upper()
    #     if rand >= 4:
    #         server_socket.sendto(message, address)
    #         time.sleep(1)
    #         print(message)