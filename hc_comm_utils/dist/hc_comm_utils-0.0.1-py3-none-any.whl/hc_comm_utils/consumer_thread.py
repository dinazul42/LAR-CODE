import threading
import queue
import logging
import time
from typing import Callable

logging_format = "%(asctime)s: %(message)s"
logging.basicConfig(format=logging_format, level=logging.INFO,
                    datefmt="%H:%M:%S")


class ConsumerThread(threading.Thread):
    def __init__(self, pipeline: queue.Queue, handler_function: Callable, name: str = None, verbose=False):
        """
        Creates a new consumer thread

        :param queue.Queue pipeline: queue object to use as pipeline through which messages are passed to the consumer
        :param Callable handler_function: function to be called to handle messages.
        :param str name: name of thread. Can be left as default.
        :param bool verbose: Should the thread print debug messages?
        """
        super().__init__(name=name)
        self.pipeline = pipeline
        self.verbose = verbose
        self.termination_event = threading.Event()  # the event can be set to signal threads they should terminate.
        self.termination_event.clear()
        self.handler_function = handler_function

    def run(self):
        while not self.termination_event.is_set():
            try:
                message = self.pipeline.get(timeout=1)  # timeout once a second to see of a termination was requested
            except queue.Empty:
                pass  # queue timeout, as it is empty, no action needed
            else:
                self.pipeline.task_done()
                self.handler_function(message)
                if self.verbose:
                    logging.info("Consumer thread %s received message", self.name)
        if self.verbose:
            logging.info("thread '%s' is exiting", self.name)

    def terminate_consumer(self):
        self.termination_event.set()


if __name__ == "__main__":
    def dummy_parser(message):
        print(str(message))

    pipe = queue.Queue()
    consumer = ConsumerThread(pipeline=pipe, handler_function=dummy_parser, name="dummy_thread", verbose=True)
    consumer.start()
    #time.sleep(3)
    pipe.put(1)
    #time.sleep(3)
    pipe.put(2)
    time.sleep(0.01)
    consumer.terminate_consumer()
    consumer.join()
