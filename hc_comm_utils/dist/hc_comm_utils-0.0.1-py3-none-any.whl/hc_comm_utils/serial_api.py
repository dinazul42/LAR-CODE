import serial
import serial.tools.list_ports
from typing import Callable, Union, BinaryIO
from numbers import Number
import queue
import threading
import logging
from .consumer_thread import ConsumerThread

log_format = "%(asctime)s: %(message)s"
logging.basicConfig(format=log_format, level=logging.INFO,
                    datefmt="%H:%M:%S")


def list_serial_ports():
    serial.tools.list_ports.main()


class SerialAPI:
    def __init__(self, port: str, baud: int, parser_function: Callable, connect: bool = False, tx_log: str = "",
                 rx_log: str = "", verbosity: int = 1, read_timeout_sec: Number = 1, write_timeout_sec: Number = 0):
        """
        :param port: comm port
        :param baud: baudrate
        :param parser_function: function to parse incoming bytes. The function must except a single bytes type argument
        :param connect: boolean, should the client try to connect upon creation
        :param tx_log: log filename to write transmitted bytes
        :param rx_log: log filename to write received bytes
        :param int verbosity: how much logging should be printed.
        :param read_timeout_sec: timeout for read from serial port
        :param write_timeout_sec: timeout for write from serial port
        """
        self.port: str = port
        self.baud: int = baud
        self.verbosity: int = verbosity
        self.is_connected: bool = False
        self.rx_pipeline = queue.Queue()  # queue used to store messages sent from host to program
        self.tx_pipeline = queue.Queue()
        self.tx_thread: Union[ConsumerThread, None] = None
        self.rx_producer: Union[threading.Thread, None] = None
        self.rx_consumer: Union[threading.Thread, None] = None
        self.termination_event = threading.Event()  # the event can be set to signal threads they should terminate.
        self.parser_function: Callable = parser_function
        self.tx_log_filename: str = tx_log
        self.rx_log_filename: str = rx_log
        self.tx_log: Union[BinaryIO, None] = None
        self.rx_log: Union[BinaryIO, None] = None
        self.serial_obj: serial.Serial = None
        self.read_timeout_sec: Number = read_timeout_sec
        self.write_timeout_sec: Number = write_timeout_sec

        if connect:
            self.connect_to_host()

    def connect_to_host(self) -> bool:
        if self.is_connected:
            self.disconnect_from_host()
        try:
            self.serial_obj = serial.Serial(port=self.port, baudrate=self.baud, timeout=self.read_timeout_sec,
                                            write_timeout=self.write_timeout_sec)
            if self.verbosity > 0:
                logging.info("Connected to %s, baudrate: %s", self.port, self.baud)
            self.is_connected = True
            if self.tx_log_filename:
                if self.tx_log:
                    self.tx_log.flush()
                    self.tx_log.close()
                self.tx_log = open(self.tx_log_filename, 'wb')
            if self.rx_log_filename:
                if self.rx_log:
                    self.rx_log.flush()
                    self.rx_log.close()
                self.rx_log = open(self.rx_log_filename, 'wb')
            self.termination_event.clear()

            self.tx_thread = ConsumerThread(pipeline=self.tx_pipeline, handler_function=self.tx_queue_handler,
                                                  name=self.port + "_tx_thread", verbose=False)
            self.tx_thread.start()
            self.rx_producer = threading.Thread(target=self._listener, name= self.port + "_rx_producer",
                                                args=(self.rx_pipeline, self.termination_event, self.serial_obj,
                                                      self.port, self.baud, self.rx_log, self.verbosity))
            self.rx_producer.start()
            self.rx_consumer = threading.Thread(target=self._handler, name=self.port + "_rx_consumer",
                                                args=(self.rx_pipeline, self.termination_event, self.parser_function,
                                                      self.verbosity))
            self.rx_consumer.start()
            return True
        except ValueError as e:
            # most likely wrong serial port params
            logging.warning(e)
            raise e
        except serial.SerialException as e:
            logging.warning("cannot config or open serial port %s", self.port)
            logging.warning(e)
            raise e
        except Exception as e:
            logging.warning(e)
            raise e

    def disconnect_from_host(self):
        self.kill_threads()
        self.serial_obj.close()
        self.serial_obj = None
        if self.tx_log:
            self.tx_log.flush()
            self.tx_log.close()
            self.tx_log = None
        if self.rx_log:
            self.rx_log.flush()
            self.rx_log.close()
            self.rx_log = None
        self.is_connected = False
        if self.verbosity > 0:
            logging.info("Disconnected from %s, baudrate: %s", self.port, self.baud)

    def tx_queue_handler(self, message: bytes):
        if self.serial_obj is not None:
            to_send = len(message)
            sent = 0
            while sent < to_send:
                try:
                    sent += self.serial_obj.write(message[sent:])
                except serial.SerialTimeoutException:
                    pass # if write timeout is used ignore
                if self.verbosity > 1:
                    logging.info('sent %s bytes to %s', sent, self.port)
            if self.tx_log:
                self.tx_log.write(message[:sent])
            return sent

    def write_to_host(self, data: bytes):
        self.tx_pipeline.put(data)

    @staticmethod
    def _listener(pipeline: queue.Queue, termination_event: threading.Event, _serial_obj: serial.Serial, port: str,
                  baud: int, rx_log: Union[BinaryIO, None], verbosity: int):
        """
        Don't call this function.
        The listener and handler form a producer consumer relationship using the pipeline.
        The listener feeds data to the pipeline.

        :param pipeline: A queue.Queue object to pass messages to consumer
        :param termination_event: A threading.Event object used to signal required disconnect.
        :param _serial_obj: A serial.Serial object to receive data from
        :param port: serial port name, used only for debug messages
        :param baud: baudrate
        :param rx_log: log filename to write received bytes
        :param int verbosity: how much logging should be printed.
        """
        while not termination_event.is_set():
            try:
                message = _serial_obj.read(3*baud)
                if len(message) > 0:
                    if verbosity > 1:
                        if verbosity > 2:
                            logging.info("Serial data received from %s: %s", port, message)
                        else:
                            logging.info("Serial data received from %s", port)
                    if rx_log:
                        rx_log.write(message)
                    pipeline.put(message)
            except Exception as e:
                # Something else happened, handle error, exit, etc.
                logging.warning(e)
                raise e
        if verbosity > 1:
            logging.info("%s thread is exiting", threading.current_thread().name)

    @staticmethod
    def _handler(pipeline: queue.Queue, termination_event: threading.Event, parser_function, verbosity: int):
        """
        Don't call this function.
        The listener and handler form a producer consumer relationship using the pipeline.
        The handler consumes messages from the pipeline, and gets them parsed.

        :param pipeline: A queue.Queue object to receive messages from producer
        :param termination_event: A threading.Event object used to signal required disconnect.
        :param parser_function: function to parse incoming bytes. The function must except a single bytes type argument
        :param int verbosity: how much logging should be printed.
        """
        while not termination_event.is_set():
            try:
                message = pipeline.get(timeout=1)  # timeout once a second to see of a termination was requested
            except queue.Empty:
                pass  # queue timeout, as it is empty, no action needed
            else:
                pipeline.task_done() # queue wasn't empty allows unblocking of other threads
                if verbosity > 2:
                    logging.info("Consumer parsing message: %s (size=%d)", message, pipeline.qsize())
                parser_function(message)

        if verbosity > 1:
            logging.info("%s thread is exiting", threading.current_thread().name)

    def kill_threads(self):
        self.termination_event.set()
        if isinstance(self.rx_producer, threading.Thread):
            self.rx_producer.join()
            self.rx_producer = None
        if isinstance(self.rx_consumer, threading.Thread):
            self.rx_consumer.join()
            self.rx_consumer = None
        if isinstance(self.tx_thread, ConsumerThread):
            self.tx_thread.terminate_consumer()
            self.tx_thread.join()
            self.tx_thread = None


if __name__ == "__main__":
    import time

    def dummy_function(data: bytes):
        print(data)

    list_serial_ports()
    serial_instance = SerialAPI("COM3", 9600, dummy_function, True)
    time.sleep(5)
    serial_instance.write_to_host(b"hi there")
    time.sleep(2)
    logging.info("about to disconnect")
    serial_instance.disconnect_from_host()
