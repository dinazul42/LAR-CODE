#from _typeshed import Self
import socket
import concurrent.futures
import logging
import queue
import threading
import copy
from typing import Callable, BinaryIO, Union
import time


format = "%(asctime)s: %(message)s"
logging.basicConfig(format=format, level=logging.INFO,
                    datefmt="%H:%M:%S")

# This object is used to signal a required disconnect
TCP_DISCONNECT_SENTINEL = "DISCONNECT\n"
STARTTIME = time.time()


class TcpClient:
    def __init__(self, hostname: str, port: int, parser_function: Callable, connect: bool = False, tx_log: str = "",
                 rx_log: str = "", verbosity: int = 1):
        """
        :param hostname: server hostname (IP)
        :param port: server port
        :param parser_function: function to parse incoming bytes. The function must except a single bytes type argument
        :param connect: boolean, should the client try to connect upon creation
        :param tx_log: log filename to write transmitted bytes
        :param rx_log: log filename to write received bytes
        :param int verbosity: how much logging should be printed.
        """
        self.hostname = hostname
        self.port = port
        self.verbosity = verbosity
        self.is_connected: bool = False
        self.thread_manager = None
        self.pipeline = queue.Queue()  # queue used to store messages sent from host to program
        self.termination_event = threading.Event()  # the event can be set to signal threads they should terminate.
        self.parser_function = parser_function
        self.tx_log_filename = tx_log
        self.rx_log_filename = rx_log
        self.tx_log: Union[BinaryIO, None] = None
        self.rx_log: Union[BinaryIO, None] = None
        self.disconnected_on_purpose = False
        self.reconnect()

    def reconnect(self):
        if self.is_connected == False:
            self.connect_to_host()
            t = threading.Timer(0.5, self.reconnect).start()

    def check_connection(self):
        if self.is_connected:
            return True
        else:
            return False

    def _threads_launcher(self):
        """
        Don't call this method. Launches producer and consumer threads upon connection
        """
        self.thread_manager = concurrent.futures.ThreadPoolExecutor(max_workers=2)
        self.thread_manager.submit(self._handler, self.pipeline, self.termination_event, self.parser_function,
                                   self.verbosity)
        self.thread_manager.submit(self._listener, self.pipeline, self.termination_event, self.socket, self.hostname,
                                   self.rx_log, self.verbosity)

    def connect_to_host(self) -> bool:
        # threading.Timer(0.5,self.connect_to_host).start()
        # if self.is_connected == True:
        #     self.disconnect_from_host()
        # else:
        # while True:
        try:
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.connect((self.hostname, self.port))
            self.is_connected = True
            if self.verbosity > 0:
                logging.info("Connected to %s:%s", self.hostname, str(self.port))
            if self.tx_log_filename:
                if self.tx_log:
                    self.tx_log.flush()
                    self.tx_log.close()
                self.tx_log = open(self.tx_log_filename, 'wb')
            if self.rx_log_filename:
                if self.rx_log:
                    self.rx_log.flush()
                    self.rx_log.close()
                self.rx_log = open(self.rx_log_filename, 'wb')
            self.termination_event.clear()
            
            
            self._threads_launcher()

        except socket.error as e:
            # Something else happened, handle error, exit, etc.
            logging.warning(e)
            time.sleep(2)
            # return False
        except Exception as e:
            logging.warning(e)
            raise e
        # time.sleep(60.0 - ((time.time() - STARTTIME) % 60.0))

    def disconnect_from_host(self):
        self.termination_event.set()
        self.pipeline.put(TCP_DISCONNECT_SENTINEL)
        if self.thread_manager is not None:
            self.thread_manager.shutdown(wait=False) # join threads
            self.thread_manager = None
        
        self.socket.close()
        if self.tx_log:
            self.tx_log.flush()
            self.tx_log.close()
            self.tx_log = None
        if self.rx_log:
            self.rx_log.flush()
            self.rx_log.close()
            self.rx_log = None
        self.is_connected = False
        logging.info("is_connected status is %s", self.is_connected)
        if self.verbosity > 0:
            logging.info("Disconnected from %s:%s", self.hostname, str(self.port))

    def write_to_host(self, data: bytes) -> Union[int, None]:
        """
        Used to send bytes to host

        :param data: required bytes to be sent
        :return: number of bytes written, None if host isn't connected.
        :rtype: Union[int, None]
        """
        if self.is_connected:
            to_send = len(data)
            sent = 0

            while sent < to_send:
                sent += self.socket.send(data[sent:])
                if self.verbosity > 1:
                    logging.info('sent %s bytes to %s:%s', sent, self.hostname, self.port)
            if self.tx_log:
                self.tx_log.write(data[:sent])
            return sent

    #@staticmethod
    def _listener(self, pipeline: queue.Queue, termination_event: threading.Event, _socket: socket.socket, hostname: str,
                  rx_log: Union[BinaryIO, None], verbosity: int):
        """
        Don't call this function.
        The listener and handler form a producer consumer relationship using the pipeline.
        The listener feeds data to the pipeline.

        :param pipeline: A queue.Queue object to pass messages to consumer
        :param termination_event: A threading.Event object used to signal required disconnect.
        :param _socket: A socket.socket object to receive data from
        :param hostname: used only for debug messages
        :param rx_log: log filename to write received bytes
        :param int verbosity: how much logging should be printed.
        """
        message = b""
        while not termination_event.is_set():
            try:
                message = self.socket.recv(4096)
            except socket.timeout:
                continue  # read timeout, no action needed
            except socket.error as e:
                # Something else happened, handle error, exit, etc.
                logging.warning(e)
                raise e
            # run if no exception occurred
            else:
                if len(message) == 0:
                    if verbosity > 0:
                        logging.info('Yoni Hamelech haya po, orderly shutdown on server end')
                        try:
                            logging.info('disconnecting from host')
                            self.disconnect_from_host()
                            # _socket.close()
                        except Exception as e:
                            logging.warning(e)
                        finally:
                            pass
                else:
                    if verbosity > 1:
                        if verbosity > 2:
                            logging.info("TCP data received from %s: %s", hostname, message)
                        else:
                            logging.info("TCP data received from %s", hostname)
                    if rx_log:
                        rx_log.write(message)
                    pipeline.put(message)
        if verbosity > 1:
            logging.info("listener thread exiting")

    # @staticmethod
    def _handler(self, pipeline: queue.Queue, termination_event: threading.Event, parser_function, verbosity: int):
        """
        Don't call this function.
        The listener and handler form a producer consumer relationship using the pipeline.
        The handler consumes messages from the pipeline, and gets them parsed.

        :param pipeline: A queue.Queue object to receive messages from producer
        :param termination_event: A threading.Event object used to signal required disconnect.
        :param parser_function: function to parse incoming bytes. The function must except a single bytes type argument
        :param int verbosity: how much logging should be printed.
        """
        while not termination_event.is_set() or not pipeline.empty():
            message = pipeline.get()
            pipeline.task_done()  # indicates to the queue that the processing on the task is complete.
            # allows unblocking of other threads
            if message.decode() == TCP_DISCONNECT_SENTINEL:
                logging.info("attempting to disconnect client")
                self.disconnected_on_purpose = True
                self.disconnect_from_host()
                logging.info("successfully disconnected client from server")
            else:
                if verbosity > 2:
                    logging.info("Consumer parsing message: %s (size=%d)", message, pipeline.qsize())
                parser_function(copy.deepcopy(message))

        if verbosity > 1:
            logging.info("parser thread exiting")

if __name__ == "__main__":
    import time
    
    def dummy_function(data: bytes):
        return str(data)
    client = TcpClient("127.0.0.1", 34866, dummy_function, True)
    time.sleep(5)
    client.write_to_host(b"hi there")
    time.sleep(2)
    #logging.info("about to disconnect")
    #client.disconnect_from_host()