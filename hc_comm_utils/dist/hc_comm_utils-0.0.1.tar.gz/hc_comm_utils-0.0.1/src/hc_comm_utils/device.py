import queue
from enum import Enum, unique, auto
from abc import ABC, abstractmethod
from . import SerialAPI, ConsumerThread, TcpClient, UdpClient
from typing import Union


@unique
class ConnectionType(Enum):
    SERIAL = auto()
    I2C = auto()
    TCP = auto()


@unique
class DeviceType(Enum):
    EvologicsSDM = auto()
    EvologicsAT = auto()
    UBLOX_GPS = auto()
    Iridium = auto()
    Unknown = auto()


class Device(ABC):
    """
    The device class should serve as base class for all devices. Cannot be instantiated.
    """
    def __init__(self, device_type: DeviceType, device_name: str, connection_type: ConnectionType,
                 tx_log_filename: str = "", rx_log_filename: str = "", use_tx_queue: bool = False):
        """
        :param device_type: DeviceType enum
        :param device_name:
        :param connection_type: ConnectionType enum
        :param tx_log_filename:
        :param rx_log_filename:
        :param bool use_tx_queue: should data be sent to the device using a queue. If so send data by adding to queue.
        """
        self.device_type = device_type
        self.device_name = device_name
        self.connection_type = connection_type
        self.is_connected: bool = False
        self.is_valid: bool = False
        self.tx_log_filename = tx_log_filename
        self.rx_log_filename = rx_log_filename
        self.use_tx_queue = use_tx_queue
        if use_tx_queue:
            self.tx_pipeline = queue.Queue()
            self.tx_thread = ConsumerThread(pipeline=self.tx_pipeline, handler_function=self.tx_queue_handler,
                                                  name=device_name + "_tx_thread", verbose=False)
            self.tx_thread.start()
        else:
            self.tx_thread = None
            self.tx_pipeline = None

    @abstractmethod
    def parse_data(self, data: bytes):
        """
        The function must be overloaded. Would be called automatically when data is received.

        :param data: date to parse
        :return:  return None
        """
        pass

    @abstractmethod
    def connect_device(self) -> bool:
        """derived class must overload this. The connection must ensure received bytes invoke parse_data"""
        pass

    @abstractmethod
    def disconnect_device(self):
        """derived class must overload this."""
        pass

    def tx_queue_handler(self, message) -> None:
        """
        If a tx queue is used, this function can be overloaded. It will be invoked for every new message in the queue
        and should send bytes to device.

        :param message: any object of a-priori known type to be sent to device.
        """
        self.send_2_device(message)

    def add_2_tx_q(self, message):
        if isinstance(self.tx_pipeline, queue.Queue):
            self.tx_pipeline.put(message)

    @abstractmethod
    def send_2_device(self, data: bytes) -> Union[int, None]:
        """
        Should return number of bytes sent to device if connected and None otherwise. Must overload this.

        :param data: data to send
        :return: number of bytes sent to device if connected and None otherwise.
        :rtype: Union[int, None]
        """
        pass

    def kill_device(self) -> None:
        """
        Should be invoked to kill device threads before exit.
        """
        if self.use_tx_queue:
            self.tx_thread.terminate_consumer()
            self.tx_thread.join()


class TcpDevice(Device, ABC):
    """Base class for all TCP devices. Cannot be instantiated."""
    def __init__(self, device_type: DeviceType, device_name: str, hostname: str = "", port: int = 0,
                 tx_log_filename: str = "", rx_log_filename: str = "", use_tx_queue: bool = False):
        """

        :param device_type: DeviceType enum
        :param device_name:
        :param hostname: server hostname (IP)
        :param port: server port
        :param tx_log_filename: log filename to write transmitted bytes
        :param rx_log_filename: log filename to write received bytes
        :param bool use_tx_queue: should data be sent to the device using a queue. If so send data by adding to queue.
        """
        self.hostname: str = hostname
        self.port: int = port

        self._client: TcpClient = None

        Device.__init__(self, device_type, device_name, ConnectionType.TCP, tx_log_filename, rx_log_filename,
                        use_tx_queue)

    def connect_device(self) -> bool:
        if self._client is None:
            self._client = TcpClient(self.hostname, self.port, self.parse_data, True, self.tx_log_filename,
                                           self.rx_log_filename)
            self.is_connected = self._client.is_connected
        else:
            self.is_connected = self._client.connect_to_host()
        return self.is_connected

    def disconnect_device(self):
        if self._client is not None:
            self._client.disconnect_from_host()
            self._client = None
            self.is_connected = False

    def send_2_device(self, data: bytes) -> Union[int, None]:
        if self._client is not None:
            return self._client.write_to_host(data)

    @abstractmethod
    def parse_data(self, data: bytes):
        """
        The function must be overloaded. Would be called automatically when data is received.

        :param data: date to parse
        :return:  return None
        """
        pass

class UdpDevice(Device, ABC):
    """Base class for all UDP devices. Cannot be instantiated."""
    def __init__(self, device_type: DeviceType, device_name: str, hostname: str = "", port: int = 0,
                 tx_log_filename: str = "", rx_log_filename: str = "", use_tx_queue: bool = False):
        """

        :param device_type: DeviceType enum
        :param device_name:
        :param hostname: server hostname (IP)
        :param port: server port
        :param tx_log_filename: log filename to write transmitted bytes
        :param rx_log_filename: log filename to write received bytes
        :param bool use_tx_queue: should data be sent to the device using a queue. If so send data by adding to queue.
        """
        self.hostname: str = hostname
        self.port: int = port

        self._client: UdpClient = None

        Device.__init__(self, device_type, device_name, ConnectionType.UDP, tx_log_filename, rx_log_filename,
                        use_tx_queue)

    def connect_device(self) -> bool:
        if self._client is None:
            self._client = UdpClient(self.hostname, self.port, self.parse_data, True, self.tx_log_filename,
                                           self.rx_log_filename)
            self.is_connected = self._client.is_connected
        else:
            self.is_connected = self._client.connect_to_host()
        return self.is_connected

    def disconnect_device(self):
        if self._client is not None:
            self._client.disconnect_from_host()
            self._client = None
            self.is_connected = False

    def send_2_device(self, data: bytes) -> Union[int, None]:
        if self._client is not None:
            return self._client.write_to_host(data)

    @abstractmethod
    def parse_data(self, data: bytes):
        """
        The function must be overloaded. Would be called automatically when data is received.

        :param data: date to parse
        :return:  return None
        """
        pass

class SerialDevice(Device, ABC):
    """Base class for all serial devices. Cannot be instantiated."""

    def __init__(self, device_type: DeviceType, device_name: str, baud: int, port: str = "",
                 tx_log_filename: str = "", rx_log_filename: str = "", use_tx_queue: bool = False):
        """

        :param device_type: DeviceType enum
        :param str device_name:
        :param int baud: baudrate
        :param str port: comm port
        :param str tx_log_filename: log filename to write transmitted bytes
        :param str rx_log_filename: log filename to write received bytes
        :param bool use_tx_queue: should data be sent to the device using a queue. If so send data by adding to queue.
        """
        self.baud: int = baud
        self.port: str = port

        self._serial_instance: SerialAPI = None

        Device.__init__(self, device_type, device_name, ConnectionType.SERIAL, tx_log_filename, rx_log_filename,
                        use_tx_queue)

    def connect_device(self) -> bool:
        if self._serial_instance is None:
            self._serial_instance = SerialAPI(self.port,self.baud, self.parse_data, True, self.tx_log_filename,
                                                    self.rx_log_filename)  # Yoni see if you you want more arguments
        self.is_connected = True
        return True

    def disconnect_device(self):
        if self._serial_instance is not None:
            self._serial_instance.disconnect_from_host()
            self._serial_instance = None
            self.is_connected = False

    def send_2_device(self, data: bytes) -> Union[int, None]:
        if self._serial_instance is not None:
            return self._serial_instance.write_to_host(data)

    @abstractmethod
    def parse_data(self, data: bytes):
        """
        The function must be overloaded. Would be called automatically when data is received.

        :param data: date to parse
        :return:  return None
        """
        pass

    def kill_device(self) -> None:
        if self._serial_instance is not None:
            self._serial_instance.kill_threads()
        Device.kill_device(self)


if __name__ == "__main__":
    import logging
    import time
    from pyubx2 import UBXReader
    '''
    class DummyTcpDevice(TcpDevice):
        def parse_data(self, data: bytes):
            logging.info("Received %s bytes: %s", len(data), data)

    dummy_device = DummyTcpDevice(DeviceType.Unknown, "device", "localhost", 4200)
    dummy_device.connect_device()
    dummy_device.send_2_device(b"hi there")
    dummy_device = DummyTcpDevice(DeviceType.Unknown, "dummy device", "localhost", 4200, use_tx_queue=True)
    dummy_device.connect_device()
    dummy_device.add_2_tx_q(b"hi there")
    time.sleep(2)
    dummy_device.add_2_tx_q(b"second try")
    time.sleep(5)
    dummy_device.disconnect_device()
    dummy_device.kill_device()
    pass
'''
    class GPS_UBX(SerialDevice):
        def parse_data(self, data: bytes):
            logging.info("Received %s bytes: %s", len(data), data)
            parsed_data = UBXReader.parse(data)
            print("lat: " + str(parsed_data.lat))
            print("lon: " + str(parsed_data.lon))
            print("height: " + str(parsed_data.height))

    gps_device = GPS_UBX(DeviceType.UBLOX_GPS, "GPS UBX", 9600, "COM3")
    gps_device.connect_device()
    time.sleep(5)
    gps_device.disconnect_device()
    gps_device.kill_device()