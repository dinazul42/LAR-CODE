from distutils.log import set_verbosity
import socket
import concurrent.futures
import logging
import queue
import threading
import copy
from typing import Callable, BinaryIO, Union
import time


format = "%(asctime)s: %(message)s"
logging.basicConfig(format=format, level=logging.INFO,
                    datefmt="%H:%M:%S")

# This object is used to signal a required disconnect
UDP_DISCONNECT_SENTINEL = object()


class UdpServer:
    def __init__(self, port: int, parser_function: Callable, tx_log: str = "", rx_log: str = "", verbosity: int = 1):
        """
        :param port: server port
        :param parser_function: function to parse incoming bytes. The function must accept a single bytes type argument
        :param tx_log: log filename to write transmitted bytes
        :param rx_log: log filename to write received bytes
        :param int verbosity: how much logging should be printed.
        """
        self.port = port
        self.verbosity = verbosity
        self.is_connected: bool = False
        self.thread_manager = None
        self.pipeline = queue.Queue()  # queue used to store messages sent from host to program
        self.termination_event = threading.Event()  # the event can be set to signal threads they should terminate.
        self.parser_function = parser_function
        self.tx_log_filename = tx_log
        self.rx_log_filename = rx_log
        self.tx_log: Union[BinaryIO, None] = None
        self.rx_log: Union[BinaryIO, None] = None
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.socket.bind(("", self.port))
        
        self.new_logs()
        self.termination_event.clear()
        self._threads_launcher()
        
                

    def _threads_launcher(self):
        """
        Don't call this method. Launches producer and consumer threads upon connection
        """
        self.thread_manager = concurrent.futures.ThreadPoolExecutor(max_workers=2)
        self.thread_manager.submit(self._handler, self.pipeline, self.termination_event, self.parser_function, self.verbosity)
        self.thread_manager.submit(self._listener, self.pipeline, self.termination_event, self.socket,self.rx_log, self.verbosity)

    def new_logs(self) -> None:
        if self.tx_log_filename:
            if self.tx_log:
                self.tx_log.flush()
                self.tx_log.close()
            self.tx_log = open(self.tx_log_filename, 'wb')
        if self.rx_log_filename:
            if self.rx_log:
                self.rx_log.flush()
                self.rx_log.close()
            self.rx_log = open(self.rx_log_filename, 'wb')
                
    def close_server(self):
        self.termination_event.set()
        self.pipeline.put(UDP_DISCONNECT_SENTINEL)

        if self.thread_manager is not None:
            self.thread_manager.shutdown(wait=False) # join threads
            self.thread_manager = None
        
        self.socket.close()
        if self.tx_log:
            self.tx_log.flush()
            self.tx_log.close()
            self.tx_log = None
        if self.rx_log:
            self.rx_log.flush()
            self.rx_log.close()
            self.rx_log = None
        if self.verbosity > 0:
            logging.info("closed port %s", str(self.port))

    def write(self, data: bytes, address: tuple) -> Union[int, None]:
        """
        Used to send bytes to host

        :param data: required bytes to be sent
        :param address: (ip_addr, port), where ip_addr is string, and port is int
        :return: number of bytes written, None if host isn't connected.
        :rtype: Union[int, None]
        """
        to_send = len(data)
        sent = 0

        while sent < to_send:
            sent += self.socket.sendto(data[sent:], address)
            if self.verbosity > 1:
                logging.info('sent %s bytes to %s:%s', sent, address[0], address[1])
        if self.tx_log:
            self.tx_log.write(data[:sent])
        return sent

    #@staticmethod
    def _listener(self, pipeline: queue.Queue, termination_event: threading.Event, _socket: socket.socket, rx_log: Union[BinaryIO, None], verbosity: int):
        """
        Don't call this function.
        The listener and handler form a producer consumer relationship using the pipeline.
        The listener feeds data to the pipeline.

        :param pipeline: A queue.Queue object to pass messages to consumer
        :param termination_event: A threading.Event object used to signal required disconnect.
        :param _socket: A socket.socket object to receive data from
        :param rx_log: log filename to write received bytes
        :param int verbosity: how much logging should be printed.
        """
        message = b""
        while not termination_event.is_set():
            try:
                message, sender_addr = self.socket.recvfrom(4096)
            except socket.timeout:
                continue  # read timeout, no action needed
            except socket.error as e:
                # Something else happened, handle error, exit, etc.
                logging.warning(e)
                raise e
            # run if no exception occurred
            else:
                if len(message) > 0:
                    if verbosity > 1:
                        if verbosity > 2:
                            logging.info("UDP data received from %s: %s", sender_addr, message)
                        else:
                            logging.info("UDP data received from %s", sender_addr)
                    if rx_log:
                        rx_log.write(message)
                    pipeline.put(message)
        if verbosity > 1:
            logging.info("listener thread exiting")

    @staticmethod
    def _handler(pipeline: queue.Queue, termination_event: threading.Event, parser_function, verbosity: int):
        """
        Don't call this function.
        The listener and handler form a producer consumer relationship using the pipeline.
        The handler consumes messages from the pipeline, and gets them parsed.

        :param pipeline: A queue.Queue object to receive messages from producer
        :param termination_event: A threading.Event object used to signal required disconnect.
        :param parser_function: function to parse incoming bytes. The function must except a single bytes type argument
        :param int verbosity: how much logging should be printed.
        """
        while not termination_event.is_set():
            message = pipeline.get()
            pipeline.task_done()  # indicates to the queue that the processing on the task is complete.
            # allows unblocking of other threads
            if message is not UDP_DISCONNECT_SENTINEL:
                if verbosity > 2:
                    logging.info("Consumer parsing message: %s (size=%d)", message, pipeline.qsize())
                parser_function(copy.deepcopy(message))

        if verbosity > 1:
            logging.info("parser thread exiting")

if __name__ == "__main__":
    import time
    
    def dummy_function(data: bytes):
        print(str(data))

    server = UdpServer(14575, dummy_function, verbosity=2)
    time.sleep(60)
    logging.info("about to disconnect")
    server.close_server()